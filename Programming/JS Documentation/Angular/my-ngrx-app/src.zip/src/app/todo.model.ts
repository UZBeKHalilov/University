export interface Todo {
    id: string;
    description: string;
    completed: boolean;
  }
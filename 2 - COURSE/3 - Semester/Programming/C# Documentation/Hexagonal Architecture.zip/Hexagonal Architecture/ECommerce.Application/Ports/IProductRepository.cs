// ECommerce.Application/Ports/IProductRepository.cs
using ECommerce.Domain.Entities;

namespace ECommerce.Application.Ports
{
    public interface IProductRepository
    {
        Task<Product> GetByIdAsync(Guid id);
        Task<IEnumerable<Product>> GetAllAsync();
        Task AddAsync(Product product);
        Task UpdateAsync(Product product);
        Task DeleteAsync(Guid id);
    }
}